package com.uc.week4retrofit.helper

object Const {
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val API_KEY = "8799fe0ead43f489bb708d57da6f933b"
    const val IMG_URL = "https://image.tmdb.org/t/p/w500/"

}