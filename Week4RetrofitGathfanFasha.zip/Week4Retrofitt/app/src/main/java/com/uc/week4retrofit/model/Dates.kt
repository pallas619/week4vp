package com.uc.week4retrofit.model

data class Dates(
    val maximum: String,
    val minimum: String
)